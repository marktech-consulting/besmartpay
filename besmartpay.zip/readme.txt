=== BeSmartPay ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://besmart.pay
Tags: woocommerce, stripe
Requires at least: 4.7
Tested up to: 5.8
Stable tag: 4.3
Requires PHP: 7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
 
This customer can modified and will be use so on bank statement will show that name for that client.